var fullImgBox = document.getElementById("fullImgBox");
var fullImg = document.getElementById("fullImg");

function openFullImg(picture){
    fullImgBox.style.display= "flex";
    fullImg.src=picture;
}

// this function is for cross icon
function closeFullImg(){
    fullImgBox.style.display= "none";
}
